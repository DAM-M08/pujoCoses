# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import date


class SchoolClass(models.Model):
    _name = 'school.class'
    _description = 'School Classes'

    name = fields.Char(string='Class Name', required=True)
    grade = fields.Selection(
        [('first', 'First'),
         ('second', 'Second'),
         ('third', 'Third'),
         ('fourth', 'Fourth')],
        string='Grade', required=True
    )
    date_begin = fields.Date(string='Start Date', required=True)
    date_end = fields.Date(string='End Date', required=True)
    tutor_id = fields.Many2one('hr.employee', string='Tutor')
    student_ids = fields.One2many('school.student', 'class_id', string='Students')
    student_number = fields.Integer(string='Number of Students', compute='_compute_student_number', store=True)
    description = fields.Text(string='Description')

    @api.depends('student_ids')
    def _compute_student_number(self):
        for record in self:
            record.student_number = len(record.student_ids)


class SchoolStudent(models.Model):
    _name = 'school.student'
    _description = 'School Students'

    name = fields.Char(string='First Name', required=True)
    last_name = fields.Char(string='Last Name', required=True)
    birthdate = fields.Date(string='Birth Date', required=True)
    id_number = fields.Char(string='ID Number', required=True)
    class_id = fields.Many2one('school.class', string='Class', ondelete='cascade')
    active = fields.Boolean(string='Active', default=True)
    age = fields.Integer(string='Age', compute='_compute_age', store=True)
    event_ids = fields.Many2many('school.event', string='Events')

    @api.depends('birthdate')
    def _compute_age(self):
        today = date.today()
        for record in self:
            if record.birthdate:
                delta = today - record.birthdate
                record.age = delta.days // 365
            else:
                record.age = 0


class SchoolEvent(models.Model):
    _name = 'school.event'
    _description = 'School Events'

    name = fields.Char(string='Event Name', required=True)
    date = fields.Date(string='Event Date', required=True)
    student_ids = fields.Many2many('school.student', string='Students')
    event_type = fields.Selection(
        [('absence', 'Absence'),
         ('delay', 'Delay'),
         ('felicitation', 'Felicitation'),
         ('behavior', 'Behavior')],
        string='Event Type', required=True
    )
    description = fields.Text(string='Description')
    event_date = fields.Date('Event Date')
    class_id = fields.Many2one('school.class', 'Class') 
    start_date = fields.Date(string='Start Date')
    teacher_id = fields.Many2one('school.teacher', string='Teacher')


# class school(models.Model):
#     _name = 'school.school'
#     _description = 'school.school'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
